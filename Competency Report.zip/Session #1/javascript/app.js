var saloon = {
    name: "The Fashion Pet",
    address: {
        state: "Vista",
        city: "CA",
        street: "The Fly Dog 1234",
        zip: "23981"
    },
    hours: {
        opening: "9:00 am",
        closing: "9:00 pm"
    },
    pets:[]
}


//Object Constructor!!!

// class Task {
//     constructor(description, priority) {
//         this.d = description;
//         this.p = priority;
//     }
// }
// var task1 = new Task("Play", "High");
// console.log(task1);
// var task2 = new Task("Nails", "Medium");
// console.log(task2);
// var task3 = new Task("Do Homework", "High");
// console.log(task3);

var counter = 0;

class Pet {
    constructor(name, age, gender, breed, service, owner, phone, payment) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.breed = breed;
        this.service = service;
        this.owner = owner;
        this.phone = phone;
        this.id = counter++;
        this.payment = payment;
    }
}

var dog = "https://previews.123rf.com/images/maximmmmum/maximmmmum1107/maximmmmum110700006/10064651-simple-illustration-with-a-dog.jpg";
var cat = "https://lh3.googleusercontent.com/proxy/KrRieWefzeEFm5pnIxgd55I_NmYj5MYFUDj22x89xeWLVnfBnU3lOXugRe7bTczJJE1GSixOKNx0QZIKaudIcc2Dhi1UTx6qtCoVsDNDOrsMtWOnwtNVNU3D64RhIQVDVt8RqtHHFm6yQ2CEzhY";
var bird = "https://media.istockphoto.com/vectors/simplistic-brush-paintings-of-a-songbird-vector-id1069785622?k=20&m=1069785622&s=612x612&w=0&h=q-j--NJZL4fd-oYqw_ValpHRCUY4wPNk6YWnnKmmXHc=";
// Create pets

var scooby = new Pet("Scooby", 60, "Male", "Dane", "Grooming", "Shagy", "555-555-5555", dog );
saloon.pets.push(scooby);
var scrappy = new Pet("Scrappy", 50, "Male", "Mixed", "Nails cut", "Shaggy", "555-555-5555", dog);
saloon.pets.push(scrappy);
var renosuke = new Pet("Renosuke", 2, "Male", "Akita", "Grooming", "Julian", "555-555-5555", dog);
saloon.pets.push(renosuke);
var tweety = new Pet("Tweety", 60, "Male", "Bird", "Nails cut", "Bugs Bunny", "999-999-9999", bird);
saloon.pets.push(tweety);

// Gets info from form and converts to variables

var txtName = document.getElementById('petName');
var txtAge = document.getElementById('petAge');
var txtGender = document.getElementById('petGender');
var txtBreed = document.getElementById('petBreed');
var txtService = document.getElementById('petService');
var txtOwner = document.getElementById('ownerName');
var txtPhone = document.getElementById('ownerPhone');
var txtPayment = document.getElementById('petPayment');

// Function for registering a pet.

function register() {
    if(txtName.value === "" || txtOwner.value === "" || txtService.value === "") {
        alert("Please enter the required fields")
    } else {
        var thePet = new Pet(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value, txtPayment.value);

        console.log(thePet);
        saloon.pets.push(thePet);

        clear();
        //display();
        displayTable();
        
        var alertElement = document.getElementById('alert');
        alertElement.classList.remove("hide");
        setTimeout(function() {
            alertElement.classList.add("hide");
        }, 3000);
    }
}

// Function clears the registered pet.

function clear() {
    txtName.value = ''; // Clearing the input field
    txtAge.value = '';
    txtGender.value = '';
    txtBreed.value = '';
    txtService.value = '';
    txtOwner.value = '';
    txtPhone.value = '';
    txtPayment.value = '';
}

function display() {
    const petSection = document.getElementById('pets');

    var tmp = '';

    for (i = 0; i < saloon.pets.length; i++) {
        tmp += `<div class="pet">
        <h3>${saloon.pets[i].name} </h3>
        <p>Age: ${saloon.pets[i].age} </p>
        <p>Gender: ${saloon.pets[i].gender} </p>
        <p>Breed: ${saloon.pets[i].breed} </p>
        <p>Service: ${saloon.pets[i].service} </p>
        <p>Owner: ${saloon.pets[i].owner} </p>
        <p>Phone: ${saloon.pets[i].phone} </p>
        <p>Phone: ${saloon.pets[i].payment} </p>
        </div>`
    }
    petSection.innerHTML = tmp;
}

function displayTable() {
    const petTable = document.getElementById('pets-table');

    var tmp = '';

    for (i = 0; i < saloon.pets.length; i++) {
        tmp += `
        <tr id=${saloon.pets[i].id}>
            <td>${saloon.pets[i].name}</td>
            <td>${saloon.pets[i].age}</td>
            <td>${saloon.pets[i].gender}</td>
            <td>${saloon.pets[i].breed}</td>
            <td>${saloon.pets[i].service}</td>
            <td>${saloon.pets[i].owner}</td>
            <td>${saloon.pets[i].phone}</td>
            <td><img class="avatar-picture" src="${saloon.pets[i].payment}"></td>
            <td onclick="deletePet(${saloon.pets[i].id})"><button>Delete</button></td>
        </tr>`
    }
    petTable.innerHTML = tmp;
}

function deletePet(id) {
    console.log("delete pet " + id);

    var row = document.getElementById(id); // selected element using id
    row.remove(); // remove element from the HTML

    for (i = 0; i < saloon.pets.length; i++) {
        var indexDelete; // variable to store the position
        if (saloon.pets[i].id === id) { // search for the id
            indexDelete = i; // update the position value
        }
    }

    saloon.pets.splice(indexDelete, 1); // delete the element from the array
}

function searchPet() {
    var txtSearch = document.getElementById("search-input").value;
    var searchString = txtSearch.toLowerCase();
    //travel the array to search the string
    saloon.pets.forEach(pet => {        
        //compare the txtsearch with all the pet names
        if (pet.name.toLowerCase() === searchString) {
            alert("Pet found.")
        
        //highlight the result
            document.getElementById(pet.id).classList.add('highlight');
        } else {
            document.getElementById(pet.id).classList.remove('highlight');
        }
    });
}


function init() {
    console.log("app.js");
    //display();
    displayTable();

    //hook events
    document.querySelector(".btn-register").addEventListener("click", register);
    document.querySelector(".btn-search").addEventListener("click", searchPet);
}
window.onload = init;
